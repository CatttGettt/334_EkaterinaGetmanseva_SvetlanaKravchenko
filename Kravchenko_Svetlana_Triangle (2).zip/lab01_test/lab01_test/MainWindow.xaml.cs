﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lab01_test
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// Кравченко Светлана
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_calculate_Click(object sender, RoutedEventArgs e)
        {
            try 
            { 

                int a = int.Parse(text_sideA.Text);
                int b = int.Parse(text_sideB.Text);
                int c = int.Parse(text_sideC.Text);

            
                if (a + b > c && a + c > b && b + c > a && a > 0 && b > 0 && c > 0)
                {
                    if (a == b && b == c)
                    {
                        MessageBox.Show("Это равносторонний треугольник", "Результат");
                    }
                    else if (a == b || a == c || b == c)
                    {
                        MessageBox.Show("Это равнобедренный треугольник", "Результат");
                    }
                    else
                    {
                        MessageBox.Show("Это разносторонний треугольник", "Результат");
                    }
                }

                else
                {
                    MessageBox.Show("Треугольник с такими сторонами не существует!", "Ошибка");
                }
            }

            catch (FormatException)
            {
                MessageBox.Show("Пожалуйста, введите целые числа во все поля", "Ошибка");
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка");
            }
        }   
    }
}
